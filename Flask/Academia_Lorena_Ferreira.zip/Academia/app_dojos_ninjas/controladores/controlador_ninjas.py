from flask import render_template, request, redirect
from app_dojos_ninjas import app
from app_dojos_ninjas.modelos.modelos_dojo import Dojo
from app_dojos_ninjas.modelos.modelos_ninjas import Ninja

@app.route('/formulario/ninjas', methods = ['GET'])
def desplegar_formulario_ninjas():
    lista_dojos = Dojo.obtener_todos()
    return render_template('/formulario_ninjas.html', lista_dojos=lista_dojos)

@app.route('/nuevo/ninja', methods=['POST'])
def crear_ninja():  
    Ninja.crear_uno(request.form)
    return redirect('/dojo')