from app_dojos_ninjas.config.mysqlconnection import connectToMySQL
from app_dojos_ninjas import BASE_DATOS
from app_dojos_ninjas.modelos.modelos_ninjas import Ninja



class Dojo:
    def __init__(self, data):
        self.id = data['id']
        self.nombre = data['nombre']
        self.fecha_creacion = data['fecha_creacion']
        self.fecha_actualizacion = data ['fecha_actualizacion']
        self.ninjas= []

    @classmethod
    def crear_uno(cls, data):
        query = """
        INSERT INTO esquema_dojo_ninjas.dojos (nombre)
        VALUES (%(nombre)s);
        """
        result = connectToMySQL(BASE_DATOS).query_db(query, data)
        if result:
            print("Consulta exitosa")
        else:
            print("Consulta fallida")

    @classmethod
    def obtener_todos(cls):
        query="""SELECT * 
                FROM dojos;"""
        results=connectToMySQL(BASE_DATOS).query_db(query)
        lista_dojos=[]
        
        for renglon in results:
            lista_dojos.append(Dojo(renglon))

        return lista_dojos
    
    @classmethod
    def obtener_uno_ninjas(cls, data):
        query = """
        SELECT *
        FROM dojos d LEFT JOIN ninjas n
            ON d.id =n.dojos_id
        WHERE d.id = %(id)s;
        """
        results = connectToMySQL(BASE_DATOS).query_db(query, data)
        informacion_dojo = Dojo(results[0])

        for renglon in results:
            if renglon['n.nombre'] is not None:
                datos_ninja = {
                    "nombre": renglon['n.nombre'],
                    "apellido": renglon['apellido'],
                    "edad": renglon['edad'],
                    "id": renglon['n.id'],
                    "dojos_id": renglon['dojos_id'],
                    "fecha_creacion": renglon['n.fecha_creacion'],
                    "fecha_actualizacion": renglon['n.fecha_actualizacion']
                }
                ninja_actual = Ninja(datos_ninja)
                informacion_dojo.ninjas.append(ninja_actual)

        return informacion_dojo


