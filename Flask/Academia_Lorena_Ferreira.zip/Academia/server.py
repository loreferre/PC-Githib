from app_dojos_ninjas import app
from app_dojos_ninjas.controladores import controlador_dojo, controlador_ninjas

if __name__=="__main__":

    app.run(debug = True)

