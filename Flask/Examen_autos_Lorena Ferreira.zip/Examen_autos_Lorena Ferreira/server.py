from app_autos import app
from app_autos.controladores import controlador_user, controlador_autos

if __name__=="__main__":
    app.run (debug =True)