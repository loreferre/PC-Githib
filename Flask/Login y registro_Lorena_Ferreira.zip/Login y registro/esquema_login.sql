SELECT *
FROM registro;

SELECT *
FROM registro;