from app_login_registro import app
from app_login_registro.controladores import controlador_user
if __name__=="__main__":    
    app.run(debug=True)   